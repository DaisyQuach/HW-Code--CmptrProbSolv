%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW4
% Due Feb 18, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Projectile Problem 2
clear, clc
%Defining Inputs:
d1 = 0.041;
d2 = 0.190;
d3 = 0.067;
v0 = 3.2;

%Initializing variables
launchAngle = 0;
angleIncrement = 0.01;
xLand = LandingDistance(d1,d2,d3,v0,launchAngle);
xTarget = 1.25;
[range, rangeAngle] = ProjectileRange(d1,d2,d3,v0);

while ((xLand < xTarget) & (launchAngle < rangeAngle))
    %Increment launch angle
    launchAngle = launchAngle + angleIncrement;
    %Compute xLand (call Landing Distance)
    xLand = LandingDistance(d1,d2,d3,v0,launchAngle);
end

shallowAngle = launchAngle;

%if/else printing results
if(xTarget <= range)
    fprintf("To hit a target at %.2f m, use a launch angle of %.2f degrees\n", xTarget, shallowAngle);
else
    fprintf("%.2f m is beyond the range of the cannon.\n ",xTarget);
    fprintf("%.3f m is the closest you can get (launch angle = %.2f degrees)\n", xLand, shallowAngle);
end
    

%% Projectile Problem 3
clear,clc
%Defining Inputs:
d1 = 0.041;
d2 = 0.190;
d3 = 0.067;
v0 = 3.2;

%Initializing variables
launchAngle = 90;
angleDecrement = 0.01;
xLand = LandingDistance(d1,d2,d3,v0,launchAngle);
xTarget = 1.25;
[range, rangeAngle] = ProjectileRange(d1,d2,d3,v0);

while((xLand < xTarget) & (launchAngle > rangeAngle))
    %Decrement launch angle
    launchAngle = launchAngle - angleDecrement;
    %Compute xLand (call Landing Distance)
    xLand = LandingDistance(d1,d2,d3,v0,launchAngle);
end

steepAngle = launchAngle;

%if/else printing results
if(xTarget <= range)
    fprintf("To hit a target at %.2f m, use a launch angle of %.2f degrees\n", xTarget, steepAngle);
else
    fprintf("%.2f m is beyond the range of the cannon.\n ",xTarget);
    fprintf("%.3f m is the closest you can get (launch angle = %.2f degrees)\n", xLand, steepAngle);
end
    





