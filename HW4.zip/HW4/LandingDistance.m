function [xLand] = LandingDistance(d1,d2,d3,v0,thetaL)
%LandingDistance Summary of this function goes here
%   Inputs: distance 1, distance, 2, distance 3, initial velocity, angle L
%   Outputs: xLand (horizontal distance traveled by the projectile
%Daisy Quach, u1282901, ME EN 1010, HW3

    g = 9.81;
    %Compute x0 and y0 
            [x0,y0] = InitialCoords(d1, d2, d3, thetaL);
    %Compute v0x and v0y 
        [v0x,v0y] = InitialVelocityComponents(v0,thetaL);
    %Solving tLand using the y-equation
        %Initialize a, b, c coefficients
            a = -g/2;
            b = v0y;
            c = y0;     
        %Calling quadratic formula to compute tLand
            tLand = Quadratic(a,b,c,-1);
    %Compute xLand from the x-equation and corresponding tLand
        xLand = x0 + v0x*tLand;
            

end

