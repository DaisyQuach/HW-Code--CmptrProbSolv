%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW7
% Due Mar 11, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Projectile Problem 1
clear,clc

%Test Case
%d = [0,0,0];
%v0 = 3.5;
%[range,rangeAngle] = ProjectileRange2(d,v0)

%Real Case
load d_vector;
v0 = 3.2;
[range,rangeAngle] = ProjectileRange2(d,v0);

%Print display and plotting "xLand vs. angle" with max range point
fprintf("The range is %.2f m at a launch angle of %.2f degrees\n", range, rangeAngle);
thetaL = 0:0.01:90;
xLand = LandingDistance(d,v0,thetaL);
figure
plot(thetaL, xLand);
hold on
plot(rangeAngle,range,'rp');
title('Projectile Theory');
xlabel('Launch Angle [deg]');
ylabel('Horizontal Distance [m]');
message = sprintf("The range is %.2f m at a launch angle of %.2f degrees\n", range, rangeAngle);
text(5,0.4,message);


%% Projectile Problem 2
clear,clc

%Test Case
%d = [0,0,0];
%v0 = 3.5;
%xTarget = 0.96;
%launchAngle = LaunchAngle(d,v0,xTarget);

%Real Case
load d_vector;
v0 = 3.2;
xTarget = 1.2;
launchAngle = LaunchAngle(d,v0,xTarget);

%Print display real case 
fprintf("To hit a target at %.2f m the launch angle should be %.2f degrees\n",xTarget, launchAngle);


%% Projectile Problem 3
clear,clc

load d_vector;
v0 = 3.2;
thetaL = 0:90;

%Without graph
%xLand = LandingDistance(d,v0,thetaL)

% With graph
LandingDistance(d,v0,thetaL);


%% Projectile Problem 4
clear,clc

filename = 'Team61_ProjectileData.xlsx';
%readmatrix(filename)
%[thetaL_exp,xLand_ave] = ProjectileData(filename)

%Plotting Graph
ProjectileData(filename);


%% Projectile Problem 5
clear,clc

%Extracting experimental launch angle and average landing distance values
%from dataset
filename = 'Team61_ProjectileData.xlsx';
[thetaL_exp,xLand_ave] = ProjectileData(filename);

%Plotting Graph
figure
ProjectileData(filename);

%Extracting theoretical landing distances using the experimental launch
%angles above and given initial velocity and position
load d_vector;
v0 = 3.30; %Alter this initial velocity for optimal SSE (i.e. < 0.005)
xLand_theoretical = LandingDistance(d,v0,thetaL_exp);

%Plotting theoretical landing distances on previous projectile data graph
hold on
LandingDistance(d,v0,thetaL_exp);

%Calculating SSE between experimental landing distance and theoretical
%landing distance
SSE = SumOfSquaredErrors(xLand_ave,xLand_theoretical);

%Message display for graph and legend
message = sprintf('The SSE is %.4f for v0 = %.2f m/s\n',SSE,v0);
text(25,0.5,message);
legend('theory','experiment');
