function [thetaL_exp,xLand_ave] = ProjectileData(filename)
%LandingDistance Summary of this function goes here
%   Inputs: filename (i.e. the dataset's filename of real life projectile data)
%   Outputs: launch angles and the average landing distance 
%Daisy Quach, u1282901, ME EN 1010, HW7

    %extracting full data set
    data = readmatrix(filename);
    %indexing launch angles as a column vector
    thetaL_exp = data(:,1);
    %indexing distances as a 2D array in cm and m
    distDataCM = data(:, 2:end);
    distDataM = distDataCM .* 0.01;
    
    %computing average horizontal distance for each angle in meters
    xLand_ave = mean(distDataM,2);
    
    
    %Creating a default "plot graph" when no outputs are assigned
    if nargout == 0
        plot(thetaL_exp, xLand_ave,'ro')
        title('Ping Pong Ball Projectile Data')
        xlabel('Launch Angle [deg]')
        ylabel('Horizontal Distance Traveled [m]')
    end

end

