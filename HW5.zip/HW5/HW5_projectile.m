%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW5
% Due Feb 25, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Modified functions
load d_vector
thetaL = 50;
v0 = 3.2;

%InitialCoords() 
[x0,y0] = InitialCoords(d,thetaL);

% LandingDistance() 
xLand = LandingDistance(d,v0,thetaL)

% ProjectileRange() 
[range, rangeAngle] = ProjectileRange(d,v0)
