%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW5
% Due Feb 25, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Linkage Problem 1
load L_vector

thetaTwo = 29

thetaFour = ThetaFour(L,thetaTwo)

%% Linkage Problem 2
load L_vector
params = [ 20.0, 0.04, 14.0 ];
thetaS = 150;

thetaL = ThetaLaunch(L,thetaS,params)

%% Linkage Problem 3
clear,clc
load L_vector
params = [ 20.0, 0.04, 14.0 ];

%initializing variables before while loop
angleIncrement = 0.01;
thetaS = 0;
maxLaunchAngle = 0;
maxUsefulServoAngle = 0;

%Run loop while thetaS is in the range of 0-180 degrees
while((thetaS >= 0) & (thetaS <= 180))
        thetaS = thetaS + angleIncrement;
        thetaL = ThetaLaunch(L, thetaS, params);
        if(thetaL > maxLaunchAngle)
            maxLaunchAngle = thetaL;
            maxUsefulServoAngle = thetaS;
        end
        
end  

%Print display
        fprintf("The max launch angle is %.2f degrees at a servo angle of %.2f degrees\n",maxLaunchAngle, maxUsefulServoAngle)
        
        