function [thetaL] = ThetaLaunch(L,thetaS,params)
    %ThetaLaunch Computes thetaL when you know the thetaS of a fourbar linkage
    %   Inputs: lengths 1-4, thetaS, and params (aka alpha & beta scaling
    %   factors and thetaL0)
    %   Outputs: thetaLaunch
    %Daisy Quach, u1282901, ME EN 1010, HW10
    
    % Index alpha, beta, and thetaL0 out of the params vector
    alpha = params(1);
    beta = params(2);
    thetaL0 = params(3);
    
    % Compute thetaSC
    thetaSC = alpha + beta*thetaS;
    
    % Compute theta2
    thetaTwo = 180 - thetaS + thetaSC;
    
    % Compute theta4 by calling your ThetaFour function
    thetaFour = ThetaFour(L,thetaTwo);
    
    % Compute thetaL
    thetaL = 180 - thetaFour + thetaL0;
    
    
    %Plot graph as default if and only if no outputs are assigned
    if nargout == 0
       plot(thetaS, thetaL,'b-');
        title('Cannon Fourbar Kinematics');
        xlabel('Servomotor Angle [deg]');
        ylabel('Launch Angle [deg]'); 
    end
    
end