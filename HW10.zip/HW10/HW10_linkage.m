%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW10 
% Due April 1, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Linkage Problem 2
clear,clc
% Initializing variables
params = [ 30.0, 0.01, 13.0 ];
load 'L_vector.mat';
filename = 'Team61_LinkageData.xlsx';
[thetaS,thetaLAve] = LinkageData(filename);
% Computing SSE value
[SSE] = CompareLinkageData(params,L, thetaS, thetaLAve)


%% Linkage Problem 3
clear,clc
% Initializing variables
load 'L_vector.mat';
filename = 'Team61_LinkageData.xlsx';
[thetaS,thetaLAve] = LinkageData(filename);

% Using fminsearch for optimal parameters
[optimal_params, SSE] = fminsearch(@CompareLinkageData, [30.0, 0.01, 13.0], [], L, thetaS, thetaLAve);



% Linkage Problem 4
figure
LinkageData(filename);
hold on 
ThetaLaunch(L,thetaS,optimal_params);
legend({'experiment','theory'},'Location','southeast');
message = sprintf('alpha = %.2f degrees\nbeta = %.2f\nthetaL0 = %.2f degrees\nSSE = %.4f',optimal_params(1),optimal_params(2),optimal_params(3),SSE);
text(20,75,message);