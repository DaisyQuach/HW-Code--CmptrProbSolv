function [thetaS,thetaLAve] = LinkageData(filename)
%LandingDistance Summary of this function goes here
%   Inputs: filename (i.e. the dataset's filename of real life projectile data)
%   Outputs: vector of servo angles (deg) and vector of average launch angles (deg) 
%Daisy Quach, u1282901, ME EN 1010, HW10

    %extracting full data set
    data = readmatrix(filename);
    %indexing servo angles (first column of file) as a column vector
    thetaS = data(:,1);
    %indexing launch angles as a 2D array of any number of columns
    thetaL = data(:, 2:end);
    
    %computing average launch angle for each servo angle in degrees
    thetaLAve = mean(thetaL,2);
    
    
    %Creating a default "plot graph" when no outputs are assigned
    if nargout == 0
        plot(thetaS, thetaLAve,'ro')
        title('Cannon Fourbar Kinematics')
        xlabel('Servomotor angle [deg]')
        ylabel('Launch angle [deg]')
    end

end