function [SSE] = SumOfSquaredErrors(x,y)
%SumOfSquaredErrors Calculates the sum of the squared errors of two vectors
%   Inputs: x and y, both vectors of n elements
%   Outputs: SSE (sum of the squared errors)
%Daisy Quach, u1282901, ME EN 1010, HW10

    %Compute the element-by-element differences ("errors") between the two vectors
    error = x - y;
    
    %Square the resulting vector to get a vector containing the "squared errors"
    errorSquared = error.^2;
    
    %Sum the vector of squared errors to get the SSE
    SSE = sum(errorSquared);

end
