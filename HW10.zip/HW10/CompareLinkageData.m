function [SSE] = CompareLinkageData(params,vectorL, vectorThetaS, vectorThetaL)
%CompareLinkageData Computes SSE of experimental and theoretical thetaL
%   Inputs: parameters alpha, beta, and thetaL0, length vector, servo angle
%   vector, thetaL vector
%   Outputs: Sum of squared errors between launch angles and theoretical
%   launch angles
%Daisy Quach, u1282901, ME EN 1010, HW10

% computing vector of theoretical launch angles
theorThetaL = ThetaLaunch(vectorL,vectorThetaS,params);
% computing SSE of experimental and theoretical launch angles
SSE = SumOfSquaredErrors(vectorThetaL,theorThetaL);

end

