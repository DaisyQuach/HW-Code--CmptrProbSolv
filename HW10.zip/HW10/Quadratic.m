function [root] = Quadratic(a,b,c,plusOrMinus)
%Quadratic Summary of this function goes here
%   Inputs: Coefficients a,b,c of the quadratic formula; plusOrMinus
%           (determines the use of + or - in the quadratic equation)
%   Outputs: root (a single root of the quadratic equation)
%Daisy Quach, u1282901, ME EN 1010, HW10

    if((b.^2 - (4.*a.*c)) >= 0)
        num = -b + (plusOrMinus).*sqrt(b.^2 - (4.*a.*c));
        denom = 2.*a;
        root = num./denom;
    else
        error("Error. Inputs for coefficients a,b,&c yield a complex root");
    end
end

