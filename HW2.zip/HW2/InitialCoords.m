function [x0,y0] = InitialCoords(d1, d2, d3, thetaL)
%InitialCoords Calculates the initial coordinates (in the x & y directions) of the projectile motion
%   Inputs: distance 1, distance 2, distance 3, angle theta (L)
%   Outputs: initial x-coordinate, initial y-coordinate
%Daisy Quach, u1282901, ME EN 1010, HW2

x0 = d2*cosd(thetaL) - d3*sind(thetaL);
y0 = d1 + d2*sind(thetaL) + d3*cosd(thetaL);
end

