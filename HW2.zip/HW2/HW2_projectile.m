%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW2
% Due Feb 4, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc


%% Problem 1
    %Testing your function (1)
        [x0Test1,y0Test1] = InitialCoords(1, 1, 1, 0);
        [x0Test2,y0Test2] = InitialCoords(1, 1, 1, 90);
        [x0Test3,y0Test3] = InitialCoords(1, 1, 1, 45);
       
    %Testing your function (2)
        [v0xTest1,v0yTest1] = InitialVelocityComponents(2,0);
        [v0xTest2,v0yTest2] = InitialVelocityComponents(2,30);
        [v0xTest3,v0yTest3] = InitialVelocityComponents(2,45);
        [v0xTest4,v0yTest4] = InitialVelocityComponents(2,60);
        [v0xTest5,v0yTest5] = InitialVelocityComponents(2,90);
         
    %Testing your function (3)
        [posRootTest1] = Quadratic(1,-1,-2,1);
        [negRootTest1] = Quadratic(1,-1,-2,-1);
        [posrootTest2] = Quadratic(2,13,15,1);
        [posrootTest2] = Quadratic(2,13,15,-1);

%% Problem 2
    %Initialize Variables:
        d1 = 0.041;
        d2 = 0.190;
        d3 = 0.067;
        thetaL = 50;
        v0 = 3.2;
        g = 9.81;
        
    %Compute x0 and y0 & print display
        [x0,y0] = InitialCoords(d1, d2, d3, thetaL);
        fprintf("Launch angle = %d degrees --> x0 is %.4f m and y0 is %.4f m\n", thetaL, x0, y0);
        
    %Compute v0x and v0y & print display
        [v0x,v0y] = InitialVelocityComponents(v0,thetaL);
        fprintf("Launch angle = %d degrees, v0 = %.1f m/s --> v0x is %.4f m/s and v0y is %.4f m/s\n", thetaL, v0, v0x, v0y);
  
    %Solving tLand using the y-equation
        %Initialize a, b, c coefficients
            a = -g/2;
            b = v0y;
            c = y0;
            
        %Calling quadratic formula to compute tLand
            tLand = Quadratic(a,b,c,-1);
            
        %Printing display
            fprintf("The landing time is %.4f s \n", tLand);

    %Compute xLand from the x-equation & print display
        xLand = x0 + v0x*tLand;
        fprintf("The landing distance is %.2f m\n", xLand);
