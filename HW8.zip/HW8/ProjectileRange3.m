function [range,rangeAngle] = ProjectileRange3(d,v0)
%ProjectileRange2 New version of the ProjectileRange function that uses a
%vector method
%   Inputs: the vector d that contains distance 1, distance 2, distance 3
%   Outputs: range and the corresponding range angle
%Daisy Quach, u1282901, ME EN 1010, HW8

    %initialize variable prior for use in for loop
    range = 0;
    rangeAngle = 0;
    
    %calculate xLand for angles 0-90 (increment 0.01); determine range and
    %rangeAngle
    for thetaL = 0:0.01:90
        xLand = LandingDistance(d,v0,thetaL);
        if(xLand > range)
            range = xLand;
            rangeAngle = thetaL;
        end
    end

end