%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW7
% Due Mar 18, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Projectile Problem 
clear,clc
%initialize variables
load d_vector;
v0 = 3.2; %m/s

%call projectile range function for range and range angle
[range,rangeAngle] = ProjectileRange3(d,v0);

%print display
fprintf("For an initial velocity of %.1f m/s,\nthe max distance is %.2f m at %.2f degrees\n",v0,range,rangeAngle);

