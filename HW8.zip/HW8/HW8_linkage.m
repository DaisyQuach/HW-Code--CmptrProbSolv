%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW7
% Due Mar 18, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Linkage Problem 2
clear,clc
load L_vector;
thetaS = 0:180;
params = [20, 0.04, 14];

%Call ThetaLaunch() w/o assigned outputs for plot
ThetaLaunch(L,thetaS,params);

%Call ThetaLaunch() w/ assigned outputs for no plot
[thetaL] = ThetaLaunch(L,thetaS,params)


%% Linkage Problem 3
clear,clc

filename = 'Team61_LinkageData.xlsx';
%readmatrix(filename)

%Plotting graph w/o assigned outputs
LinkageData(filename);

%Not plotting graph w/ assigned outputs
[thetaS,thetaLAve] = LinkageData(filename)


%% Linkage Problem 4
clear,clc

%obtaining thetaS and thetaLAve from file
filename = 'Team61_LinkageData.xlsx';
[thetaS,thetaLAve] = LinkageData(filename);

%plotting linkage data
figure
LinkageData(filename);

%calculating theoretical launch angles with given length, servo angle, and
%parameters
load L_vector;
params = [25.9, 0.042, 12.5]; %adjust paramters for better overlap on graph; try to get SSE~10
thetaLTheoretical = ThetaLaunch(L,thetaS,params);

%plotting theta launch function on previous figure
hold on
ThetaLaunch(L,thetaS,params);

%calculating sum of squared erros b/w experimental launch angles and
%theoretical launch angles for manually set parameters
[SSE] = SumOfSquaredErrors(thetaLAve,thetaLTheoretical);

%Adding legend and message on plot
legend({'experiment','theory'},'Location','southeast');
message = sprintf("alpha = %.1f degrees\nbeta = %.2f\nLaunch angle offset = %.1f degrees\nSSE = %.1f\n", params,SSE);
text(10,80,message);

