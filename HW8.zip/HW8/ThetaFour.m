function [thetaFour] = ThetaFour(L,thetaTwo)
    %ThetaFour Computes thetaFour when you know the lengths and thetaTwo of a fourbar linkage
    %   Inputs: lengths 1,2,3,&4 and thetaTwo of a fourbar linkage
    %   Outputs: thetaFour
    %Daisy Quach, u1282901, ME EN 1010, HW8
    
    %Indexing length sides to their corresponding element in vector L
    L1 = L(1);
    L2 = L(2);
    L3 = L(3);
    L4 = L(4);
    
    %Computing K values
    K1 = L1/L2;
    K2 = L1/L4;
    K3 = (L1^2 + L2^2 - L3^2 + L4^2)/(2*L2*L4);
    
    %Computing A,B,C coefficients
    A = cosd(thetaTwo) - K1 - (K2*cosd(thetaTwo)) +  K3;
    B = -2*sind(thetaTwo);
    C = K1 - ((K2+1)*cosd(thetaTwo)) + K3;
    
    %Computing theta4 by calling Quadratic function
    thetaFour = 2.*atand(Quadratic(A,B,C,-1));
end