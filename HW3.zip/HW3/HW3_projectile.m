%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW2
% Due Feb 4, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Problem 1
%{
    %Testing modified Quadratic() function
        %Test Case 1: (b^2 -4ac) > 0
            plusTest1 = Quadratic(2,13,15,1)
            minusTest1 = Quadratic(2,13,15,-1)
        %Test Case 2: (b^2 - 4ac) = 0
            plusTest2 = Quadratic(16,8,1,1)
            minusTest2 = Quadratic(16,8,1,-1)
        %Test Case 3: (b^2 - 4ac) < 0
            plusTest3 = Quadratic(2,-3,3,1)
            minusTest3 = Quadratic(2,-3,3,-1)
%}    
    
%% Problem 2    
    %Initializing variables 
        d1 = 0.041;
        d2 = 0.190;
        d3 = 0.067;
        thetaL = 50;
        v0 = 3.2;
    
    %Calling LandingDistance function
        xLand = LandingDistance(d1,d2,d3,v0,thetaL);
        
    %Printing Display
        fprintf("For launch angle = %.0f degrees and v0 = %.1f m/s, the landing distance is %.2f m\n",thetaL,v0,xLand)


%% Problem 3
    %Initializing variables
        d1 = 0.041;
        d2 = 0.190;
        d3 = 0.067;
        v0 = 3.2;
    
    %Calling ProjectileRange function
        [range, rangeAngle] = ProjectileRange(d1,d2,d3,v0);
        
    %Print display
        fprintf("The range is %.2f m at a launch angle of %.2f degrees.\n",range, rangeAngle)
