function [range, rangeAngle] = ProjectileRange(d1,d2,d3,v0)
%ProjectileRange Calculates maximum horizontal distance and the angle that yields it 
%   Inputs: distance 1, distance 2, distance 3, initial velocity
%   Outputs: range (maximum achievable horizontal distance) & range angle 
%            (the angle that yields that max distance)
%Daisy Quach, u1282901, ME EN 1010, HW3

    thetaL = 0;
    range = 0;
    rangeAngle = 0;
    angleIncrement = 0.01;
    
    while(thetaL <= 90)
        xLand = LandingDistance(d1,d2,d3,v0,thetaL);
        if(xLand > range)
            range = xLand;
            rangeAngle = thetaL;
        end
        thetaL = thetaL + angleIncrement;
    end    
    
end

