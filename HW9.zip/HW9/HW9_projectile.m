%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW7
% Due Mar 25, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Projectile Problem 1
clear,clc

%initializing variables
load d_vector.mat
v0 = 3.2;
xTarget = [0.90, 1.05, 1.20];

%running test cases with given test values
launchAngle1 = LaunchAngle(d,v0,0.90);
launchAngle2 = LaunchAngle(d,v0,1.05);
launchAngle3 = LaunchAngle(d,v0,1.20);
launchAngle = LaunchAngle(d,v0,xTarget);

%Print display "vectors" w/for loop
for n = 1:length(xTarget)
    fprintf("To hit a target at %.2f m the launch angle should be %.2f degrees\n",xTarget(n),launchAngle(n));
end


%% Projectile Problem 2
clear,clc
load 'd_vector.mat'
v0 = 3.25;
filename = 'Team61_ProjectileData.xlsx';
[thetaL,expXLand] = ProjectileData(filename);

SSE = CompareProjectileData(v0,d,thetaL,expXLand)


%% Projectile Problem 3
clear,clc
load 'd_vector.mat'
filename = 'Team61_ProjectileData.xlsx';
[thetaL,expXLand] = ProjectileData(filename);

[best_v0,best_SSE] = fminbnd(@CompareProjectileData, 0, 5, [],d,thetaL,expXLand)


%% Projectile Problem 4
clear,clc,close all
%Plot projectile data
filename = 'Team61_ProjectileData.xlsx';
ProjectileData(filename);

%Plot Landing distance w/ given conditions
hold on
load 'd_vector.mat'
[thetaL,expXLand] = ProjectileData(filename);
[v0,SSE] = fminbnd(@CompareProjectileData, 0, 5, [],d,thetaL,expXLand);
LandingDistance(d,v0,thetaL);

%Adding legend
legend('experiment','theory');

%Adding message label
message = sprintf('The SSE is %.4f for an initial velocity of %.2f m/s\n',SSE,v0);
text(25,0.25,message);

