function [SSE] = CompareProjectileData(v0,d,thetaL,expXLand)
%InitialVelocityComponents Converts initial velocity into its x&y component
%   Inputs: initial velocity, distance vector, vector of launch angles,
%           vector of experimental landing distances (average of trials)
%   Outputs: sum of squared errors between experimental landing distance
%            and theoretical landing distance values
%Daisy Quach, u1282901, ME EN 1010, HW9

theorXLand = LandingDistance(d,v0,thetaL);

SSE = SumOfSquaredErrors(theorXLand,expXLand);

end