function [range,rangeAngle] = ProjectileRange2(d,v0)
%ProjectileRange2 New version of the ProjectileRange function that uses a
%vector method
%   Inputs: the vector d that contains distance 1, distance 2, distance 3
%   Outputs: range and the corresponding range angle
%Daisy Quach, u1282901, ME EN 1010, HW7

    %create a vector of launch angles from 0 to 90 (angle increment of
    %0.01)
    thetaL = 0:0.01:90;

    %call LandingDistance to get corresponding vector of xLand values
    xLand = LandingDistance(d,v0,thetaL);

    %call max function to get the max xLand value (range) AND the index/ 
    %element #/bucket # of max value
    [range,rangeIndex] = max(xLand);
    
    %use indexing to get the range angle (i.e. use the index/bucket # to 
    %index the range angle out of the launch angle vector
    rangeAngle = thetaL(rangeIndex);


end

