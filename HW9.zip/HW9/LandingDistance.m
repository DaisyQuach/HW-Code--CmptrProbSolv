function [xLand] = LandingDistance(d,v0,thetaL)
%LandingDistance Summary of this function goes here
%   Inputs: distance 1, distance, 2, distance 3, initial velocity, angle L
%   Outputs: xLand (horizontal distance traveled by the projectile
%Daisy Quach, u1282901, ME EN 1010, HW9

    g = 9.81;
    %Compute x0 and y0 
            [x0,y0] = InitialCoords(d, thetaL);
    %Compute v0x and v0y 
        [v0x,v0y] = InitialVelocityComponents(v0,thetaL);
    %Solving tLand using the y-equation
        %Initialize a, b, c coefficients
            a = -g/2;
            b = v0y;
            c = y0;     
        %Calling quadratic formula to compute tLand
            tLand = Quadratic(a,b,c,-1);
    %Compute xLand from the x-equation and corresponding tLand
        xLand = x0 + v0x .* tLand;
            
        
    %Creating a default "plot graph" when no outputs are assigned
    if nargout == 0
        plot(thetaL, xLand,'b-')
        title('Ping Pong Ball Projectile Data')
        xlabel('Launch Angle [deg]')
        ylabel('Horizontal Distance Traveled [m]')
    end

end

