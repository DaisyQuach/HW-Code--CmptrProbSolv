%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW7
% Due Mar 25, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Practice Problem 1
clear,clc
load('d_vector')
% initial velocity vector of 3-3.5 m/s at an increment of 0.05
v0 = 3.0:0.05:3.5;

% for loop for generating range and range angles for v0 vector by element
% allows us to use vectors on non-vectorized functions
for n = 1:length(v0)
   v0Value = v0(n);
   [range(n),rangeAngle(n)] = ProjectileRange2(d,v0Value);
end


% plotting Range vs. v0 and Range Angle vs. v0 on subplot
figure
% Top plot
trajPlots = subplot(2,1,1);
plot(v0,range,'ro') 
title('Range');
xlabel('Initial Velocity [m/s]');
ylabel('Range [m]');
% Bottom plot
trajPlots = subplot(2,1,2);
plot(v0,rangeAngle,'bx') 
title('Vertical Position');
xlabel('Initial Velocity [m/s]');
ylabel('Range Angle [deg]');



