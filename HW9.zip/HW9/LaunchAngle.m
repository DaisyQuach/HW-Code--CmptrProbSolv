function [launchAngle] = LaunchAngle(d,v0,xTarget)
%LaunchAngle Summary of this function goes here
%   Inputs: the vector d that contains distance 1, distance 2, distance 3,
%           initial velocity, and target landing distance
%   Outputs: launch angle needed to achieve xTarget
%Daisy Quach, u1282901, ME EN 1010, HW9

    for n = 1:length(xTarget)
        xTargetVal = xTarget(n);

        %Calling ProjectileRange2 function to get the range angle
        [range,rangeAngle] = ProjectileRange2(d,v0);

        %Create a vector of launch angles between range angle and 90 (call
        %linspace)
        thetaL = linspace(rangeAngle,90,10000);


        %Call landing distance to get the corresponding vector of xLand values
        xLand = LandingDistance(d,v0,thetaL);

        %Compute absolute difference between xLand and xTarget
        absDiff = abs(xLand - xTargetVal);

        %Call the min function to get the minimum absolute difference and the 
        %index/element #/bucket #
        [minAbsDiff, minAbsDiffIndex] = min(absDiff);

        %Use indexing to get best launch angle ... index out of thetaL vector
        %using the index/bucket # of the min abs diff value
        launchAngle(n) = thetaL(minAbsDiffIndex);

    end
end

