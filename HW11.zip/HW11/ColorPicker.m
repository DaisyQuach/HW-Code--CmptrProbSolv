function [rgbVecOfPic] = ColorPicker(rgbImArr)
%ColorPicker Tells you the rgb values of a user-selected pixel
%   Input: RGB image array
%   Output: Vector containing R,G, and B values of the selected pixel
%Daisy Quach, u1282901, ME EN 1010, HW11

% display image
image(rgbImArr)
axis image

% obtain selected pixel from user
[clickedCol,clickedRow] = ginput(1);

% round the row and column values to the nearest integer 
% so that you can use them to index the image array
clickedCol = round(clickedCol);
clickedRow = round(clickedRow);

% Indexing out RGB values of selected pixel and converting it to a vector
% output
R = rgbImArr(clickedRow,clickedCol,1);
G = rgbImArr(clickedRow,clickedCol,2);
B = rgbImArr(clickedRow,clickedCol,3);
rgbVecOfPic = [R,G,B]


end

