function [centroidRowVec,centroidColVec,rgbImArr] = FindAllTargetCentroids(rgbImArr,targetRGBVec)
%FindAllTargetCentroids Targets and blacks out given target color
%   Input: RGB image array, target color given as RGB vector values
%   Output: row and column coordinates of (the six) target's centroid in a vector, modified image
%Daisy Quach, u1282901, ME EN 1010, HW11outputArg1 = inputArg1;

for t = 1:6
    [centroidRowVec(t),centroidColVec(t),rgbImArr] = FindTargetCentroid(rgbImArr,targetRGBVec);
end

end

