%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW10 
% Due April 8, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Image Processing Problem A
image1 = imread('test_image1.bmp');
ColorPicker(image1)


%% Image Processing Problem B
image2 = imread('test_image2.bmp');
disp('Please click on the yellow target square');
targetRGBVec = ColorPicker(image2)
[centroidRow,centroidCol,modIm] = FindTargetCentroid(image2,targetRGBVec);
centroidRow
centroidCol
image(modIm)
axis image


%% Image Processing Problem C
image3 = imread('test_image3.bmp');
disp('Please click on the yellow target square');
targetRGBVec = ColorPicker(image3)
[centroidRowVec,centroidColVec,modIm] = FindAllTargetCentroids(image3,targetRGBVec);
centroidRowVec
centroidColVec
image(modIm)
axis image
hold on
plot(centroidColVec(1),centroidRowVec(1),'wx');
plot(centroidColVec(2),centroidRowVec(2),'wx');
plot(centroidColVec(3),centroidRowVec(3),'wx');
plot(centroidColVec(4),centroidRowVec(4),'wx');
plot(centroidColVec(5),centroidRowVec(5),'wx');
plot(centroidColVec(6),centroidRowVec(6),'wx');

