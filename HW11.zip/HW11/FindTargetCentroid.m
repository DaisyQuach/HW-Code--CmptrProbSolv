function [centroidRow,centroidCol,modIm] = FindTargetCentroid(rgbImArr,targetRGBVec)
%FindTargetCentroid Finds centroid coordinates of target and modifies it
%   Input: RGB image array, target color given in RGB vector values
%   Output: row and column coordinates of target's centroid, modified image
%Daisy Quach, u1282901, ME EN 1010, HW11outputArg1 = inputArg1;

    % Checking where image matches our target color
    logArray = rgbImArr(:,:,1)==targetRGBVec(1) & rgbImArr(:,:,2)==targetRGBVec(2) & rgbImArr(:,:,3)==targetRGBVec(3);

    % finding row and column coordinates where the color matches
    [matchRows,matchCols] = find(logArray==1);
    % TOP LEFT CORNER of the target color shape (i.e. rectangle) in the image
    firstMatchRow = matchRows(1);
    firstMatchCol = matchCols(1);
    % obtaining size of image (aka end values of the image array)
    [rows,cols,colors] = size(logArray); 

    % For loops that checks the "size" of target after finding its top left
    % corner
    % Computing where the last column of current target is
    for c = firstMatchCol:cols
        if logArray(firstMatchRow,c+1)==0
            break
        end
    end
    lastMatchCol = c;
    % Computing where the last row of current target is

    for r = firstMatchRow:rows
        if logArray(r+1,firstMatchCol)==0
            break
        end
    end
    lastMatchRow = r;

    % Computing centroid of target based on corners of target
    centroidRow = (firstMatchRow + lastMatchRow)/2;
    centroidCol = (firstMatchCol + lastMatchCol)/2;
    
    % Modifying image to black out the target
    modIm = rgbImArr;
    modIm(firstMatchRow:lastMatchRow,firstMatchCol:lastMatchCol,:) = 0;
    figure
    image(modIm)
    axis image
    

end

