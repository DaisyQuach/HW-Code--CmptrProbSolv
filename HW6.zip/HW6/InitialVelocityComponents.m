function [v0x,v0y] = InitialVelocityComponents(v0,thetaL)
%InitialVelocityComponents Converts initial velocity into its x&y component
%   Inputs: initial velocity, angle theta (L)
%   Outputs: initial velocity in the x-direction, initial velocity in the
%            y-direction
%Daisy Quach, u1282901, ME EN 1010, HW5

v0x = v0*cosd(thetaL);
v0y = v0*sind(thetaL);
end

