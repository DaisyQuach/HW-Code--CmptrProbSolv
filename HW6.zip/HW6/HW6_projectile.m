%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW6
% Due Mar 4, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc

%% Projectile Problem 1
clear,clc
%initializing vectors a,b,c
a = [2, 2, 2, 2];
b = [10, -10, 2, -2];
c = [12 12 -12 -12];

%calculating positive root of vectors a,b,c
plusOrMinus = 1;
posRoot = Quadratic(a,b,c,plusOrMinus);

%calculating negative root of vectors a,b,c
plusOrMinus = -1;
negRoot = Quadratic(a,b,c,plusOrMinus);

%Printing the resulting roots
fprintf('The roots for polynomial 1 are %d and %d.\n', posRoot(1),negRoot(1));
fprintf('The roots for polynomial 2 are %d and %d.\n', posRoot(2),negRoot(2));
fprintf('The roots for polynomial 3 are %d and %d.\n', posRoot(3),negRoot(3));
fprintf('The roots for polynomial 4 are %d and %d.\n', posRoot(4),negRoot(4));


%% Projectile Problem 2
clear,clc
%initializing variables
%testing code
%d = [0,0,0];
%v0 = 3.5;
%thetaL = 5:10:85;

%real case values
load d_vector;
v0 = 3.2;
thetaL = 0:1:90;

%calculating xLand as a vector with corresponding distances and angles
xLand = LandingDistance(d,v0,thetaL);

%plotting launch angle vs. horizontal distance graph
figure
plot(thetaL, xLand);
%axis([0,90,-0.2,1.4]);
title('Projectile Theory');
xlabel('Launch Angle [deg]');
ylabel('Horizontal Distance [m]');


%% Projectile 3
clear,clc
%initialize variables
load d_vector;
v0 = 3.2;

%Calling LandingDistance() to generate vector of landing distance w/ launch
%angles of 0-90 degrees
thetaL = 0:90;
xLand = LandingDistance(d,v0,thetaL);

%Plotting landing distance vs. launch angle
plot(thetaL,xLand,'r-');
title('Projectile Theory');
xlabel('Launch Angle [deg]');
ylabel('Horizontal Distance [m]');

%Establishing useful launch angles and corresponding useful xLand, where 0.8 < xLand < 1.3 m
usefulXLandLoc = (xLand > 0.8) & (xLand < 1.3);
usefulXLandVal = xLand(usefulXLandLoc);
usefulThetaLVal = thetaL(usefulXLandLoc);

%Plotting usefulXLand vs. usefulThetaL on the same plot
hold on
plot(usefulThetaLVal,usefulXLandVal, 'k+'); 

%Establishing usable launch angles (i.e. physically possible) and correspond xLand, where angles
%~25 to ~85 degrees
usableThetaLLoc = (thetaL >= 25) & (thetaL <= 85);
usableThetaLVal = thetaL(usableThetaLLoc);
usableXLandVal = xLand(usableThetaLLoc);

%Plotting usableXLand vs. usableXTheta
plot(usableThetaLVal,usableXLandVal,'go');

%Adding a legend to the graph
legend('theory','useful angles','usable angles');

