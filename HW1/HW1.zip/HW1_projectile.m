%%%%%%%%%%%%%%%%%%%%%
% Daisy Quach
% u1282901
% ME EN 1010 Lab Section 7
% HW1
% Due Jan 28, 2021
%%%%%%%%%%%%%%%%%%%%%

clear, clc


%% Problem 1
%{
%Computing x0 and y0:
 %Declaring Variables (i.e. setting up distance and angle values):
    d1 = 1;
    d2 = d1;
    d3 = d1;
    angleTheta = 45;
 %Calculating x0:
    x0 = d2*cosd(angleTheta) - d3*sind(angleTheta)
 %Calculating y0:
    y0 = d1 + (d2*sind(angleTheta)) + (d3*cosd(angleTheta))

%}
    
%% Problem 2
%{
%Computing v0x and v0y:
 %Declaring Variables (i.e. setting up initial velocity)
    v0 = 2;
    angleTheta = 90;
 %Calculating v0x:
    v0x = v0*cosd(angleTheta)
 %Calculating v0y:
    v0y = v0*sind(angleTheta)

%}

%% Problem 3
%{
%Computing posRoot and negRoot from quadratic formula
 %Declaring Variables 
    a = 2;
    b = 13;
    c = 15;
 %Calculating negRoot
    negRoot = (-b - sqrt(b^2 - 4*a*c)) / (2*a)
 %Calculating posRoot
    posRoot = (-b + sqrt(b^2 - 4*a*c)) / (2*a)

%}

%% Problem 4
%Computing landing distance (by using previous code)

%Declaring Variables:
    d1 = 0.041;
    d2 = 0.190;
    d3 = 0.067;
    v0 = 3.2;
    angleTheta = 50;
    g = 9.81;

%Computing x0 and y0:
     %Calculating x0:
        x0 = d2*cosd(angleTheta) - d3*sind(angleTheta)
     %Calculating y0:
        y0 = d1 + (d2*sind(angleTheta)) + (d3*cosd(angleTheta))
    
 
%Computing v0x and v0y:
     %Calculating v0x:
        v0x = v0*cosd(angleTheta)
     %Calculating v0y:
        v0y = v0*sind(angleTheta)    


%Computing posRoot and negRoot from quadratic formula:
     %Declaring Variables (i.e. setting up a,b,c)
        a = -g/2;
        b = v0y;
        c = y0;
     %Calculating negRoot
        negRoot = (-b - sqrt(b^2 - 4*a*c)) / (2*a)
     %Calculating posRoot
        posRoot = (-b + sqrt(b^2 - 4*a*c)) / (2*a)
    

%Computing landing distance:
     %Step1: Determining the time it takes for object to land
      %negRoot results in a postive time, which makes physical sense
        tLand = negRoot
     %Step 2: plug in tLand into kinematics formula for the x-direction
        xland = (v0x * tLand)+ x0 
     

